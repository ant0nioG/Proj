package com.example.antonio.app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BuscaActivity extends AppCompatActivity {
    private EditText buscar;
    private Button btbuscar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busca);

        buscar = (EditText)findViewById(R.id.txtbuscar);
        btbuscar = (Button)findViewById(R.id.btnbuscar);

        btbuscar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                valida(buscar.getText().toString());
            }
        });
    }

    private void valida(String curso){
        if ( curso.equals("curso1") ){
            Intent intent = new Intent(BuscaActivity.this, ListaActividades.class);
            startActivity(intent);
        }else{
            Toast.makeText(BuscaActivity.this,"No existe el curso", Toast.LENGTH_SHORT).show();
        }
    }
}
