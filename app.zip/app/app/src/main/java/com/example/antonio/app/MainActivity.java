package com.example.antonio.app;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private EditText Usuario;
    private EditText Password;
    private TextView Info;
    private Button Ingresar;
    private int count = 3;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Usuario = (EditText)findViewById(R.id.txtusuario);
        Password = (EditText)findViewById(R.id.txtpass);
        Info = (TextView)findViewById(R.id.txtinf);
        Ingresar = (Button)findViewById(R.id.btnregresar);

        Info.setText("Intentos restantes: 3");

        Ingresar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                valida(Usuario.getText().toString(),Password.getText().toString());
            }
        });
    }

    private void valida(String userName, String userPassword){
        if ((userName.equals("admin")) && (userPassword.equals("admin")) ){
            Intent intent = new Intent(MainActivity.this , BuscaActivity.class);
            startActivity(intent);
        }else{
            count--;

            Info.setText("Intentos restantes: " + String.valueOf(count));

            if(count == 0){
                Ingresar.setEnabled(false);
            }
        }
    }
}

