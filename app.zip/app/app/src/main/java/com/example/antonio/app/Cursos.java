package com.example.antonio.app;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by Antonio on 27-10-2017.
 */

public class Cursos extends ActionBarActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bcursos_layout);
    }
}
