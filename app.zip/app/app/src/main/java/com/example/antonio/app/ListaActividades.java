package com.example.antonio.app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaActividades extends AppCompatActivity {
    private Button btregresa;
    private ListView actividadesV;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_actividades);

        btregresa = (Button)findViewById(R.id.btnregresa);
        actividadesV = (ListView)findViewById(R.id.listaActividades);

        ArrayList listado = new ArrayList();
        listado.add("Actividad 1: nombre actividad");
        listado.add("Actividad 2: nombre actividad");
        listado.add("Actividad 3: nombre actividad");
        listado.add("Actividad 4: nombre actividad");
        listado.add("Actividad 5: nombre actividad");
        listado.add("Actividad 6: nombre actividad");
        listado.add("Actividad 7: nombre actividad");
        listado.add("Actividad 8: nombre actividad");
        listado.add("Actividad 9: nombre actividad");
        listado.add("Actividad 10: nombre actividad");

        ArrayAdapter adaptador = new ArrayAdapter(this,android.R.layout.simple_list_item_1,listado);
        actividadesV.setAdapter(adaptador);

        actividadesV.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                int posicion = position;
                String itemValue = (String) actividadesV.getItemAtPosition(position);
                Intent intento = new Intent(ListaActividades.this, ListaAlumnos.class);
                startActivity(intento);
            }
        });

        btregresa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intento = new Intent(ListaActividades.this, BuscaActivity.class);
                startActivity(intento);

            }
        });
    }
}
