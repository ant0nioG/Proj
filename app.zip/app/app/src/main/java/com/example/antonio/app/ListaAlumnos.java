package com.example.antonio.app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class ListaAlumnos extends AppCompatActivity {
    private Button btregresar;
    private ListView listaV;
    private String t = "si";
    private String nt = "no";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_alumnos);

        listaV = (ListView)findViewById(R.id.listView);
        btregresar = (Button)findViewById(R.id.btnregresar);

        ArrayList listado = new ArrayList();
        listado.add("Juan peres, materiales: " + t);
        listado.add("Carlitoschandia, meteriales: " + nt);
        listado.add("Nicolas garrido, materiales: " + nt);
        listado.add("María candia, materiales: " + t);

        ArrayAdapter adaptador = new ArrayAdapter(this,android.R.layout.simple_list_item_1,listado);
        listaV.setAdapter(adaptador);

        btregresar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ListaAlumnos.this, ListaActividades.class);
                startActivity(intent);
            }
        });
    }


}

